/********************************************************************************
** Form generated from reading UI file 'vit.ui'
**
** Created by: Qt User Interface Compiler version 6.3.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_VIT_H
#define UI_VIT_H

#include <QtCore/QVariant>
#include <QtWidgets/QAbstractButton>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QDialogButtonBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QVBoxLayout>

QT_BEGIN_NAMESPACE

class Ui_vit
{
public:
    QVBoxLayout *verticalLayout;
    QSpacerItem *verticalSpacer;
    QLabel *lVit;
    QSpinBox *sVit;
    QDialogButtonBox *buttonBox;

    void setupUi(QDialog *vit)
    {
        if (vit->objectName().isEmpty())
            vit->setObjectName(QString::fromUtf8("vit"));
        vit->resize(347, 98);
        vit->setMaximumSize(QSize(347, 98));
        verticalLayout = new QVBoxLayout(vit);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout->addItem(verticalSpacer);

        lVit = new QLabel(vit);
        lVit->setObjectName(QString::fromUtf8("lVit"));
        QFont font;
        font.setPointSize(13);
        font.setBold(true);
        lVit->setFont(font);
        lVit->setAlignment(Qt::AlignCenter);

        verticalLayout->addWidget(lVit);

        sVit = new QSpinBox(vit);
        sVit->setObjectName(QString::fromUtf8("sVit"));

        verticalLayout->addWidget(sVit);

        buttonBox = new QDialogButtonBox(vit);
        buttonBox->setObjectName(QString::fromUtf8("buttonBox"));
        buttonBox->setOrientation(Qt::Horizontal);
        buttonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);

        verticalLayout->addWidget(buttonBox);


        retranslateUi(vit);
        QObject::connect(buttonBox, &QDialogButtonBox::accepted, vit, qOverload<>(&QDialog::accept));
        QObject::connect(buttonBox, &QDialogButtonBox::rejected, vit, qOverload<>(&QDialog::reject));

        QMetaObject::connectSlotsByName(vit);
    } // setupUi

    void retranslateUi(QDialog *vit)
    {
        vit->setWindowTitle(QCoreApplication::translate("vit", "Dialog", nullptr));
        lVit->setText(QCoreApplication::translate("vit", "Choisir la nouvelle vitesse de d\303\251filment", nullptr));
    } // retranslateUi

};

namespace Ui {
    class vit: public Ui_vit {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_VIT_H
