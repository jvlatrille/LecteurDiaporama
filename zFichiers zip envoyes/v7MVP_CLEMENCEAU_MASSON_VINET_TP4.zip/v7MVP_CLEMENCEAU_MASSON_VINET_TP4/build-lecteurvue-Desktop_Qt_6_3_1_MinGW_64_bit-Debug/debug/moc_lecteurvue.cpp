/****************************************************************************
** Meta object code from reading C++ file 'lecteurvue.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.3.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../code/lecteurvue.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'lecteurvue.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.3.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_lecteurVue_t {
    const uint offsetsAndSize[40];
    char stringdata0[323];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(offsetof(qt_meta_stringdata_lecteurVue_t, stringdata0) + ofs), len 
static const qt_meta_stringdata_lecteurVue_t qt_meta_stringdata_lecteurVue = {
    {
QT_MOC_LITERAL(0, 10), // "lecteurVue"
QT_MOC_LITERAL(11, 20), // "diaporamaSelectionne"
QT_MOC_LITERAL(32, 0), // ""
QT_MOC_LITERAL(33, 11), // "diaporamaId"
QT_MOC_LITERAL(45, 15), // "demanderAvancer"
QT_MOC_LITERAL(61, 15), // "demanderReculer"
QT_MOC_LITERAL(77, 22), // "demanderChangerVitesse"
QT_MOC_LITERAL(100, 30), // "demanderChangerModeAutomatique"
QT_MOC_LITERAL(131, 25), // "demanderChangerModeManuel"
QT_MOC_LITERAL(157, 20), // "demanderChargerDiapo"
QT_MOC_LITERAL(178, 28), // "recevoirDiaporamaSelectionne"
QT_MOC_LITERAL(207, 20), // "demanderEnleverDiapo"
QT_MOC_LITERAL(228, 15), // "demanderAPropos"
QT_MOC_LITERAL(244, 18), // "quitterApplication"
QT_MOC_LITERAL(263, 15), // "majPresentation"
QT_MOC_LITERAL(279, 10), // "titreDiapo"
QT_MOC_LITERAL(290, 10), // "titreImage"
QT_MOC_LITERAL(301, 9), // "categorie"
QT_MOC_LITERAL(311, 4), // "rang"
QT_MOC_LITERAL(316, 6) // "chemin"

    },
    "lecteurVue\0diaporamaSelectionne\0\0"
    "diaporamaId\0demanderAvancer\0demanderReculer\0"
    "demanderChangerVitesse\0"
    "demanderChangerModeAutomatique\0"
    "demanderChangerModeManuel\0"
    "demanderChargerDiapo\0recevoirDiaporamaSelectionne\0"
    "demanderEnleverDiapo\0demanderAPropos\0"
    "quitterApplication\0majPresentation\0"
    "titreDiapo\0titreImage\0categorie\0rang\0"
    "chemin"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_lecteurVue[] = {

 // content:
      10,       // revision
       0,       // classname
       0,    0, // classinfo
      12,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       1,       // signalCount

 // signals: name, argc, parameters, tag, flags, initial metatype offsets
       1,    1,   86,    2, 0x06,    1 /* Public */,

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       4,    0,   89,    2, 0x0a,    3 /* Public */,
       5,    0,   90,    2, 0x0a,    4 /* Public */,
       6,    0,   91,    2, 0x0a,    5 /* Public */,
       7,    0,   92,    2, 0x0a,    6 /* Public */,
       8,    0,   93,    2, 0x0a,    7 /* Public */,
       9,    0,   94,    2, 0x0a,    8 /* Public */,
      10,    1,   95,    2, 0x0a,    9 /* Public */,
      11,    0,   98,    2, 0x0a,   11 /* Public */,
      12,    0,   99,    2, 0x0a,   12 /* Public */,
      13,    0,  100,    2, 0x0a,   13 /* Public */,
      14,    5,  101,    2, 0x0a,   14 /* Public */,

 // signals: parameters
    QMetaType::Void, QMetaType::UInt,    3,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::UInt,    3,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString, QMetaType::QString, QMetaType::QString, QMetaType::QString, QMetaType::QString,   15,   16,   17,   18,   19,

       0        // eod
};

void lecteurVue::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<lecteurVue *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->diaporamaSelectionne((*reinterpret_cast< std::add_pointer_t<uint>>(_a[1]))); break;
        case 1: _t->demanderAvancer(); break;
        case 2: _t->demanderReculer(); break;
        case 3: _t->demanderChangerVitesse(); break;
        case 4: _t->demanderChangerModeAutomatique(); break;
        case 5: _t->demanderChangerModeManuel(); break;
        case 6: _t->demanderChargerDiapo(); break;
        case 7: _t->recevoirDiaporamaSelectionne((*reinterpret_cast< std::add_pointer_t<uint>>(_a[1]))); break;
        case 8: _t->demanderEnleverDiapo(); break;
        case 9: _t->demanderAPropos(); break;
        case 10: _t->quitterApplication(); break;
        case 11: _t->majPresentation((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[3])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[4])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[5]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (lecteurVue::*)(unsigned int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&lecteurVue::diaporamaSelectionne)) {
                *result = 0;
                return;
            }
        }
    }
}

const QMetaObject lecteurVue::staticMetaObject = { {
    QMetaObject::SuperData::link<QMainWindow::staticMetaObject>(),
    qt_meta_stringdata_lecteurVue.offsetsAndSize,
    qt_meta_data_lecteurVue,
    qt_static_metacall,
    nullptr,
qt_incomplete_metaTypeArray<qt_meta_stringdata_lecteurVue_t
, QtPrivate::TypeAndForceComplete<lecteurVue, std::true_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<unsigned int, std::false_type>
, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<unsigned int, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<const QString &, std::false_type>, QtPrivate::TypeAndForceComplete<const QString &, std::false_type>, QtPrivate::TypeAndForceComplete<const QString &, std::false_type>, QtPrivate::TypeAndForceComplete<const QString &, std::false_type>, QtPrivate::TypeAndForceComplete<const QString &, std::false_type>


>,
    nullptr
} };


const QMetaObject *lecteurVue::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *lecteurVue::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_lecteurVue.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int lecteurVue::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 12)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 12;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 12)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 12;
    }
    return _id;
}

// SIGNAL 0
void lecteurVue::diaporamaSelectionne(unsigned int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
