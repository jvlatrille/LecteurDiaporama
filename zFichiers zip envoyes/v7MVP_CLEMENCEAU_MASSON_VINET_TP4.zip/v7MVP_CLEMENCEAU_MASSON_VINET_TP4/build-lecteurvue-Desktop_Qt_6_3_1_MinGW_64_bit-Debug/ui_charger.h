/********************************************************************************
** Form generated from reading UI file 'charger.ui'
**
** Created by: Qt User Interface Compiler version 6.3.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CHARGER_H
#define UI_CHARGER_H

#include <QtCore/QVariant>
#include <QtWidgets/QAbstractButton>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QDialogButtonBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QVBoxLayout>

QT_BEGIN_NAMESPACE

class Ui_charger
{
public:
    QVBoxLayout *verticalLayout_2;
    QLabel *label;
    QComboBox *listDiapos;
    QSpacerItem *verticalSpacer;
    QDialogButtonBox *buttonBox;

    void setupUi(QDialog *charger)
    {
        if (charger->objectName().isEmpty())
            charger->setObjectName(QString::fromUtf8("charger"));
        charger->resize(400, 300);
        verticalLayout_2 = new QVBoxLayout(charger);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        label = new QLabel(charger);
        label->setObjectName(QString::fromUtf8("label"));
        QFont font;
        font.setPointSize(20);
        font.setBold(true);
        label->setFont(font);
        label->setAlignment(Qt::AlignCenter);

        verticalLayout_2->addWidget(label);

        listDiapos = new QComboBox(charger);
        listDiapos->setObjectName(QString::fromUtf8("listDiapos"));

        verticalLayout_2->addWidget(listDiapos);

        verticalSpacer = new QSpacerItem(40, 40, QSizePolicy::Minimum, QSizePolicy::Minimum);

        verticalLayout_2->addItem(verticalSpacer);

        buttonBox = new QDialogButtonBox(charger);
        buttonBox->setObjectName(QString::fromUtf8("buttonBox"));
        buttonBox->setOrientation(Qt::Horizontal);
        buttonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);

        verticalLayout_2->addWidget(buttonBox);


        retranslateUi(charger);
        QObject::connect(buttonBox, &QDialogButtonBox::accepted, charger, qOverload<>(&QDialog::accept));
        QObject::connect(buttonBox, &QDialogButtonBox::rejected, charger, qOverload<>(&QDialog::reject));

        QMetaObject::connectSlotsByName(charger);
    } // setupUi

    void retranslateUi(QDialog *charger)
    {
        charger->setWindowTitle(QCoreApplication::translate("charger", "Dialog", nullptr));
        label->setText(QCoreApplication::translate("charger", "Charger un diaporama", nullptr));
    } // retranslateUi

};

namespace Ui {
    class charger: public Ui_charger {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CHARGER_H
