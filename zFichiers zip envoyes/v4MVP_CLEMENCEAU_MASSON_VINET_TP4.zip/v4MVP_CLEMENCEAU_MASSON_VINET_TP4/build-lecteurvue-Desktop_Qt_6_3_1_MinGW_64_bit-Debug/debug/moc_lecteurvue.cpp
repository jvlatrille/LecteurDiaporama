/****************************************************************************
** Meta object code from reading C++ file 'lecteurvue.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.3.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../code/lecteurvue.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'lecteurvue.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.3.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_lecteurVue_t {
    const uint offsetsAndSize[34];
    char stringdata0[261];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(offsetof(qt_meta_stringdata_lecteurVue_t, stringdata0) + ofs), len 
static const qt_meta_stringdata_lecteurVue_t qt_meta_stringdata_lecteurVue = {
    {
QT_MOC_LITERAL(0, 10), // "lecteurVue"
QT_MOC_LITERAL(11, 15), // "demanderAvancer"
QT_MOC_LITERAL(27, 0), // ""
QT_MOC_LITERAL(28, 15), // "demanderReculer"
QT_MOC_LITERAL(44, 22), // "demanderChangerVitesse"
QT_MOC_LITERAL(67, 30), // "demanderChangerModeAutomatique"
QT_MOC_LITERAL(98, 25), // "demanderChangerModeManuel"
QT_MOC_LITERAL(124, 20), // "demanderChargerDiapo"
QT_MOC_LITERAL(145, 20), // "demanderEnleverDiapo"
QT_MOC_LITERAL(166, 15), // "demanderAPropos"
QT_MOC_LITERAL(182, 18), // "quitterApplication"
QT_MOC_LITERAL(201, 15), // "majPresentation"
QT_MOC_LITERAL(217, 10), // "titreDiapo"
QT_MOC_LITERAL(228, 10), // "titreImage"
QT_MOC_LITERAL(239, 9), // "categorie"
QT_MOC_LITERAL(249, 4), // "rang"
QT_MOC_LITERAL(254, 6) // "chemin"

    },
    "lecteurVue\0demanderAvancer\0\0demanderReculer\0"
    "demanderChangerVitesse\0"
    "demanderChangerModeAutomatique\0"
    "demanderChangerModeManuel\0"
    "demanderChargerDiapo\0demanderEnleverDiapo\0"
    "demanderAPropos\0quitterApplication\0"
    "majPresentation\0titreDiapo\0titreImage\0"
    "categorie\0rang\0chemin"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_lecteurVue[] = {

 // content:
      10,       // revision
       0,       // classname
       0,    0, // classinfo
      10,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       1,    0,   74,    2, 0x0a,    1 /* Public */,
       3,    0,   75,    2, 0x0a,    2 /* Public */,
       4,    0,   76,    2, 0x0a,    3 /* Public */,
       5,    0,   77,    2, 0x0a,    4 /* Public */,
       6,    0,   78,    2, 0x0a,    5 /* Public */,
       7,    0,   79,    2, 0x0a,    6 /* Public */,
       8,    0,   80,    2, 0x0a,    7 /* Public */,
       9,    0,   81,    2, 0x0a,    8 /* Public */,
      10,    0,   82,    2, 0x0a,    9 /* Public */,
      11,    5,   83,    2, 0x0a,   10 /* Public */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString, QMetaType::QString, QMetaType::QString, QMetaType::QString, QMetaType::QString,   12,   13,   14,   15,   16,

       0        // eod
};

void lecteurVue::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<lecteurVue *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->demanderAvancer(); break;
        case 1: _t->demanderReculer(); break;
        case 2: _t->demanderChangerVitesse(); break;
        case 3: _t->demanderChangerModeAutomatique(); break;
        case 4: _t->demanderChangerModeManuel(); break;
        case 5: _t->demanderChargerDiapo(); break;
        case 6: _t->demanderEnleverDiapo(); break;
        case 7: _t->demanderAPropos(); break;
        case 8: _t->quitterApplication(); break;
        case 9: _t->majPresentation((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[3])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[4])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[5]))); break;
        default: ;
        }
    }
}

const QMetaObject lecteurVue::staticMetaObject = { {
    QMetaObject::SuperData::link<QMainWindow::staticMetaObject>(),
    qt_meta_stringdata_lecteurVue.offsetsAndSize,
    qt_meta_data_lecteurVue,
    qt_static_metacall,
    nullptr,
qt_incomplete_metaTypeArray<qt_meta_stringdata_lecteurVue_t
, QtPrivate::TypeAndForceComplete<lecteurVue, std::true_type>
, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<const QString &, std::false_type>, QtPrivate::TypeAndForceComplete<const QString &, std::false_type>, QtPrivate::TypeAndForceComplete<const QString &, std::false_type>, QtPrivate::TypeAndForceComplete<const QString &, std::false_type>, QtPrivate::TypeAndForceComplete<const QString &, std::false_type>


>,
    nullptr
} };


const QMetaObject *lecteurVue::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *lecteurVue::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_lecteurVue.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int lecteurVue::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 10)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 10;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 10)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 10;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
