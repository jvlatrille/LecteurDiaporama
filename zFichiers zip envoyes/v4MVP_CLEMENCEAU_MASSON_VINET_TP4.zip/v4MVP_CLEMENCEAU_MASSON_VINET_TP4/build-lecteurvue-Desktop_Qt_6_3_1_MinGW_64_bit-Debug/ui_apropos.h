/********************************************************************************
** Form generated from reading UI file 'apropos.ui'
**
** Created by: Qt User Interface Compiler version 6.3.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_APROPOS_H
#define UI_APROPOS_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QVBoxLayout>

QT_BEGIN_NAMESPACE

class Ui_apropos
{
public:
    QVBoxLayout *verticalLayout_2;
    QVBoxLayout *verticalLayout;
    QLabel *label;
    QSpacerItem *verticalSpacer;
    QLabel *label_2;
    QLabel *label_3;
    QLabel *label_4;
    QLabel *label_5;
    QSpacerItem *verticalSpacer_2;

    void setupUi(QDialog *apropos)
    {
        if (apropos->objectName().isEmpty())
            apropos->setObjectName(QString::fromUtf8("apropos"));
        apropos->resize(436, 300);
        verticalLayout_2 = new QVBoxLayout(apropos);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        label = new QLabel(apropos);
        label->setObjectName(QString::fromUtf8("label"));
        QFont font;
        font.setPointSize(25);
        font.setBold(true);
        label->setFont(font);
        label->setAlignment(Qt::AlignCenter);

        verticalLayout->addWidget(label);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Minimum);

        verticalLayout->addItem(verticalSpacer);

        label_2 = new QLabel(apropos);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        verticalLayout->addWidget(label_2);

        label_3 = new QLabel(apropos);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        verticalLayout->addWidget(label_3);

        label_4 = new QLabel(apropos);
        label_4->setObjectName(QString::fromUtf8("label_4"));

        verticalLayout->addWidget(label_4);

        label_5 = new QLabel(apropos);
        label_5->setObjectName(QString::fromUtf8("label_5"));

        verticalLayout->addWidget(label_5);

        verticalSpacer_2 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Minimum);

        verticalLayout->addItem(verticalSpacer_2);


        verticalLayout_2->addLayout(verticalLayout);


        retranslateUi(apropos);

        QMetaObject::connectSlotsByName(apropos);
    } // setupUi

    void retranslateUi(QDialog *apropos)
    {
        apropos->setWindowTitle(QCoreApplication::translate("apropos", "Dialog", nullptr));
        label->setText(QCoreApplication::translate("apropos", "A propos : ", nullptr));
        label_2->setText(QCoreApplication::translate("apropos", "Version : V4 MVP", nullptr));
        label_3->setText(QCoreApplication::translate("apropos", "Date de cr\303\251ation : 14 mai 2024", nullptr));
        label_4->setText(QCoreApplication::translate("apropos", "Auteurs de l'application : ", nullptr));
        label_5->setText(QCoreApplication::translate("apropos", "CLEMENCEAU Edouard, MASSON Rafael, VINET LATRILLE Jules", nullptr));
    } // retranslateUi

};

namespace Ui {
    class apropos: public Ui_apropos {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_APROPOS_H
